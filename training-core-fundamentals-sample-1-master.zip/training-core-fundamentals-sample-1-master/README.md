# CloudBees Core Fundamentals Sample

A Maven application that builds and tests on Java 8 and Java 11 and deploys with Java 8.
Shows the stages of development and how we can use shared agents to automatically add and remove agent capacity from Client Masters.
