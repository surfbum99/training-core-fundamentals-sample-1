#!/usr/bin/env bash

echo Running Performance tests...
# Using placeholder instead
# ./mvn -B gatling:execute
sleep $(( 10 + $RANDOM % 10 ))
echo Performance tests done.

exit 0
