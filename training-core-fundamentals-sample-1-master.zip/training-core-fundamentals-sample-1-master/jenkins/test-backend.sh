#!/usr/bin/env bash

mvn -B -DtestFailureIgnore test
exit 0
